import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../providers/photo_provider.dart';
import '../widgets/ad_banner_widget.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final autoSave = ref.watch(autoSaveProvider);
    final highQualityExport = ref.watch(highQualityExportProvider);
    final watermarkEnabled = ref.watch(watermarkEnabledProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          // App Settings Section
          _buildSectionHeader('App Settings'),
          _buildSettingsTile(
            icon: Icons.save,
            title: 'Auto Save',
            subtitle: 'Automatically save processed images',
            trailing: Switch(
              value: autoSave,
              onChanged: (value) {
                ref.read(autoSaveProvider.notifier).state = value;
              },
            ),
          ),
          _buildSettingsTile(
            icon: Icons.high_quality,
            title: 'High Quality Export',
            subtitle: 'Export images in maximum quality',
            trailing: Switch(
              value: highQualityExport,
              onChanged: (value) {
                ref.read(highQualityExportProvider.notifier).state = value;
              },
            ),
          ),
          _buildSettingsTile(
            icon: Icons.branding_watermark,
            title: 'Watermark',
            subtitle: 'Add app watermark to exported images',
            trailing: Switch(
              value: watermarkEnabled,
              onChanged: (value) {
                ref.read(watermarkEnabledProvider.notifier).state = value;
              },
            ),
          ),

          const SizedBox(height: 24),

          // Premium Section
          _buildSectionHeader('Premium'),
          _buildSettingsTile(
            icon: Icons.star,
            title: 'Upgrade to Premium',
            subtitle: 'Unlock all features and remove ads',
            trailing: const Icon(Icons.arrow_forward_ios),
            onTap: () => _showPremiumDialog(context),
          ),
          _buildSettingsTile(
            icon: Icons.restore,
            title: 'Restore Purchases',
            subtitle: 'Restore your premium subscription',
            trailing: const Icon(Icons.arrow_forward_ios),
            onTap: () => _restorePurchases(context),
          ),

          const SizedBox(height: 24),

          // Storage Section
          _buildSectionHeader('Storage'),
          _buildSettingsTile(
            icon: Icons.folder,
            title: 'Storage Location',
            subtitle: 'Choose where to save processed images',
            trailing: const Icon(Icons.arrow_forward_ios),
            onTap: () => _showStorageOptions(context),
          ),
          _buildSettingsTile(
            icon: Icons.delete_sweep,
            title: 'Clear Cache',
            subtitle: 'Free up storage space',
            trailing: const Icon(Icons.arrow_forward_ios),
            onTap: () => _clearCache(context),
          ),

          const SizedBox(height: 24),

          // About Section
          _buildSectionHeader('About'),
          _buildSettingsTile(
            icon: Icons.info,
            title: 'About Smart Photo Enhancer',
            subtitle: 'Version 1.0.0',
            trailing: const Icon(Icons.arrow_forward_ios),
            onTap: () => _showAboutDialog(context),
          ),
          _buildSettingsTile(
            icon: Icons.privacy_tip,
            title: 'Privacy Policy',
            subtitle: 'Read our privacy policy',
            trailing: const Icon(Icons.arrow_forward_ios),
            onTap: () => _openPrivacyPolicy(context),
          ),
          _buildSettingsTile(
            icon: Icons.description,
            title: 'Terms of Service',
            subtitle: 'Read our terms of service',
            trailing: const Icon(Icons.arrow_forward_ios),
            onTap: () => _openTermsOfService(context),
          ),
          _buildSettingsTile(
            icon: Icons.feedback,
            title: 'Send Feedback',
            subtitle: 'Help us improve the app',
            trailing: const Icon(Icons.arrow_forward_ios),
            onTap: () => _sendFeedback(context),
          ),

          const SizedBox(height: 24),

          // Ad banner
          const AdBannerWidget(),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8, top: 8),
      child: Text(
        title,
        style: const TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.bold,
          color: Colors.blue,
        ),
      ),
    );
  }

  Widget _buildSettingsTile({
    required IconData icon,
    required String title,
    required String subtitle,
    Widget? trailing,
    VoidCallback? onTap,
  }) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: Icon(icon, color: Colors.blue),
        title: Text(title),
        subtitle: Text(subtitle),
        trailing: trailing,
        onTap: onTap,
      ),
    );
  }

  void _showPremiumDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Row(
          children: [
            Icon(Icons.star, color: Colors.amber),
            const SizedBox(width: 8),
            const Text('Go Premium'),
          ],
        ),
        content: const Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Unlock premium features:'),
            SizedBox(height: 8),
            Text('• Unlimited high-quality exports'),
            Text('• Premium backgrounds'),
            Text('• Advanced AI enhancements'),
            Text('• No ads'),
            Text('• Priority processing'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Maybe Later'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              _purchasePremium(context);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.amber,
              foregroundColor: Colors.black,
            ),
            child: const Text('Upgrade Now'),
          ),
        ],
      ),
    );
  }

  void _restorePurchases(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Restoring purchases...'),
        backgroundColor: Colors.blue,
      ),
    );
  }

  void _showStorageOptions(BuildContext context) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Container(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Text(
              'Storage Location',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 20),
            ListTile(
              leading: const Icon(Icons.phone_android),
              title: const Text('Internal Storage'),
              subtitle: const Text('Save to device internal storage'),
              onTap: () => Navigator.pop(context),
            ),
            ListTile(
              leading: const Icon(Icons.sd_card),
              title: const Text('SD Card'),
              subtitle: const Text('Save to external SD card'),
              onTap: () => Navigator.pop(context),
            ),
            ListTile(
              leading: const Icon(Icons.cloud),
              title: const Text('Cloud Storage'),
              subtitle: const Text('Save to cloud storage (Premium)'),
              onTap: () => Navigator.pop(context),
            ),
          ],
        ),
      ),
    );
  }

  void _clearCache(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Clear Cache'),
        content: const Text(
          'This will delete all temporary files and free up storage space. Are you sure?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Cache cleared successfully'),
                  backgroundColor: Colors.green,
                ),
              );
            },
            child: const Text('Clear'),
          ),
        ],
      ),
    );
  }

  void _showAboutDialog(BuildContext context) {
    showAboutDialog(
      context: context,
      applicationName: 'Smart Photo Enhancer',
      applicationVersion: '1.0.0',
      applicationIcon: const Icon(Icons.photo_camera, size: 48),
      children: [
        const Text(
          'Transform your photos with AI-powered enhancements including quality improvement, color correction, face retouching, and background replacement.',
        ),
        const SizedBox(height: 16),
        const Text(
          'Developed with Flutter and powered by advanced AI models.',
        ),
      ],
    );
  }

  void _openPrivacyPolicy(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Opening privacy policy...'),
        backgroundColor: Colors.blue,
      ),
    );
  }

  void _openTermsOfService(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Opening terms of service...'),
        backgroundColor: Colors.blue,
      ),
    );
  }

  void _sendFeedback(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Opening feedback form...'),
        backgroundColor: Colors.blue,
      ),
    );
  }

  void _purchasePremium(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Opening premium purchase...'),
        backgroundColor: Colors.amber,
      ),
    );
  }
}

