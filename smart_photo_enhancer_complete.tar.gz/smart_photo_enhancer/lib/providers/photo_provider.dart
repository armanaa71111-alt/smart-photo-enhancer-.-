import 'dart:io';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:path_provider/path_provider.dart';
import '../models/photo_model.dart';
import '../services/api_service.dart';
import '../services/image_picker_service.dart';
import '../utils/image_utils.dart';

// Providers
final apiServiceProvider = Provider<ApiService>((ref) => ApiService());
final imagePickerServiceProvider = Provider<ImagePickerService>((ref) => ImagePickerService());

// Photo state provider
final photoProvider = StateNotifierProvider<PhotoNotifier, PhotoState>((ref) {
  return PhotoNotifier(
    ref.read(apiServiceProvider),
    ref.read(imagePickerServiceProvider),
  );
});

// Photo list provider
final photoListProvider = StateNotifierProvider<PhotoListNotifier, List<PhotoModel>>((ref) {
  return PhotoListNotifier();
});

// Current photo provider
final currentPhotoProvider = StateProvider<PhotoModel?>((ref) => null);

// Processing status provider
final processingStatusProvider = StateProvider<Map<String, ProcessingStatus>>((ref) => {});

class PhotoState {
  final PhotoModel? currentPhoto;
  final bool isLoading;
  final String? error;
  final Map<String, dynamic> processingProgress;

  PhotoState({
    this.currentPhoto,
    this.isLoading = false,
    this.error,
    this.processingProgress = const {},
  });

  PhotoState copyWith({
    PhotoModel? currentPhoto,
    bool? isLoading,
    String? error,
    Map<String, dynamic>? processingProgress,
  }) {
    return PhotoState(
      currentPhoto: currentPhoto ?? this.currentPhoto,
      isLoading: isLoading ?? this.isLoading,
      error: error,
      processingProgress: processingProgress ?? this.processingProgress,
    );
  }
}

class PhotoNotifier extends StateNotifier<PhotoState> {
  final ApiService _apiService;
  final ImagePickerService _imagePickerService;

  PhotoNotifier(this._apiService, this._imagePickerService) : super(PhotoState());

  // Pick image from camera
  Future<void> pickFromCamera() async {
    try {
      state = state.copyWith(isLoading: true, error: null);
      
      final imageFile = await _imagePickerService.pickFromCamera();
      if (imageFile != null) {
        final photoModel = await _imagePickerService.createPhotoModel(imageFile);
        state = state.copyWith(currentPhoto: photoModel, isLoading: false);
      } else {
        state = state.copyWith(isLoading: false);
      }
    } catch (e) {
      state = state.copyWith(isLoading: false, error: e.toString());
    }
  }

  // Pick image from gallery
  Future<void> pickFromGallery() async {
    try {
      state = state.copyWith(isLoading: true, error: null);
      
      final imageFile = await _imagePickerService.pickFromGallery();
      if (imageFile != null) {
        final photoModel = await _imagePickerService.createPhotoModel(imageFile);
        state = state.copyWith(currentPhoto: photoModel, isLoading: false);
      } else {
        state = state.copyWith(isLoading: false);
      }
    } catch (e) {
      state = state.copyWith(isLoading: false, error: e.toString());
    }
  }

  // Set current photo
  void setCurrentPhoto(PhotoModel photo) {
    state = state.copyWith(currentPhoto: photo);
  }

  // Clear current photo
  void clearCurrentPhoto() {
    state = state.copyWith(currentPhoto: null);
  }

  // Upload and process image
  Future<String?> uploadImage() async {
    if (state.currentPhoto == null) return null;

    try {
      state = state.copyWith(isLoading: true, error: null);
      
      final imageFile = File(state.currentPhoto!.originalPath);
      final fileId = await _apiService.uploadImage(imageFile);
      
      state = state.copyWith(isLoading: false);
      return fileId;
    } catch (e) {
      state = state.copyWith(isLoading: false, error: e.toString());
      return null;
    }
  }

  // Apply enhancement
  Future<void> applyEnhancement(
    String fileId,
    EnhancementType type, {
    Map<String, dynamic>? parameters,
  }) async {
    if (state.currentPhoto == null) return;

    try {
      state = state.copyWith(isLoading: true, error: null);
      
      String outputFilename;
      
      switch (type) {
        case EnhancementType.qualityEnhancement:
          final scale = parameters?['scale'] ?? 2;
          outputFilename = await _apiService.enhanceQuality(fileId, scale: scale);
          break;
        case EnhancementType.colorCorrection:
          outputFilename = await _apiService.correctColors(fileId);
          break;
        case EnhancementType.sharpening:
          final strength = parameters?['strength'] ?? 1.0;
          outputFilename = await _apiService.sharpenImage(fileId, strength: strength);
          break;
        case EnhancementType.denoising:
          outputFilename = await _apiService.denoiseImage(fileId);
          break;
        case EnhancementType.brightening:
          final factor = parameters?['factor'] ?? 1.5;
          outputFilename = await _apiService.brightenImage(fileId, factor: factor);
          break;
        case EnhancementType.faceRetouching:
          outputFilename = await _apiService.retouchFace(fileId);
          break;
        case EnhancementType.backgroundRemoval:
          outputFilename = await _apiService.removeBackground(fileId);
          break;
        case EnhancementType.backgroundReplacement:
          final backgroundFile = parameters?['backgroundFile'] as File?;
          if (backgroundFile == null) throw Exception('Background file required');
          final blurAmount = parameters?['blurAmount'] ?? 0.0;
          final dimAmount = parameters?['dimAmount'] ?? 0.0;
          outputFilename = await _apiService.replaceBackground(
            fileId,
            backgroundFile,
            blurAmount: blurAmount,
            dimAmount: dimAmount,
          );
          break;
      }

      // Download processed image
      final appDir = await getApplicationDocumentsDirectory();
      final localPath = '${appDir.path}/$outputFilename';
      await _apiService.downloadImage(outputFilename, localPath);

      // Create enhancement record
      final enhancement = Enhancement(
        id: ImageUtils.generateId(),
        type: type,
        parameters: parameters ?? {},
        appliedAt: DateTime.now(),
      );

      // Update photo model
      final updatedPhoto = state.currentPhoto!.copyWith(
        processedPath: localPath,
        lastModified: DateTime.now(),
        appliedEnhancements: [...state.currentPhoto!.appliedEnhancements, enhancement],
        status: ProcessingStatus.completed,
      );

      state = state.copyWith(currentPhoto: updatedPhoto, isLoading: false);
    } catch (e) {
      state = state.copyWith(isLoading: false, error: e.toString());
    }
  }

  // Save processed image
  Future<String?> saveProcessedImage() async {
    if (state.currentPhoto?.processedPath == null) return null;

    try {
      final appDir = await getApplicationDocumentsDirectory();
      final savedDir = Directory('${appDir.path}/saved_images');
      if (!await savedDir.exists()) {
        await savedDir.create(recursive: true);
      }

      final timestamp = DateTime.now().millisecondsSinceEpoch;
      final savedPath = '${savedDir.path}/enhanced_$timestamp.png';
      
      final processedFile = File(state.currentPhoto!.processedPath!);
      await processedFile.copy(savedPath);

      return savedPath;
    } catch (e) {
      state = state.copyWith(error: e.toString());
      return null;
    }
  }

  // Clear error
  void clearError() {
    state = state.copyWith(error: null);
  }

  // Update processing progress
  void updateProcessingProgress(String operation, double progress) {
    final updatedProgress = Map<String, dynamic>.from(state.processingProgress);
    updatedProgress[operation] = progress;
    state = state.copyWith(processingProgress: updatedProgress);
  }
}

class PhotoListNotifier extends StateNotifier<List<PhotoModel>> {
  PhotoListNotifier() : super([]);

  // Add photo to list
  void addPhoto(PhotoModel photo) {
    state = [...state, photo];
  }

  // Remove photo from list
  void removePhoto(String photoId) {
    state = state.where((photo) => photo.id != photoId).toList();
  }

  // Update photo in list
  void updatePhoto(PhotoModel updatedPhoto) {
    state = state.map((photo) {
      return photo.id == updatedPhoto.id ? updatedPhoto : photo;
    }).toList();
  }

  // Clear all photos
  void clearPhotos() {
    state = [];
  }

  // Get photo by ID
  PhotoModel? getPhotoById(String id) {
    try {
      return state.firstWhere((photo) => photo.id == id);
    } catch (e) {
      return null;
    }
  }

  // Get photos by status
  List<PhotoModel> getPhotosByStatus(ProcessingStatus status) {
    return state.where((photo) => photo.status == status).toList();
  }

  // Sort photos by date
  void sortByDate({bool ascending = false}) {
    state = [...state]..sort((a, b) {
      return ascending 
          ? a.createdAt.compareTo(b.createdAt)
          : b.createdAt.compareTo(a.createdAt);
    });
  }
}

// Enhancement parameters providers
final qualityEnhancementScaleProvider = StateProvider<int>((ref) => 2);
final sharpeningStrengthProvider = StateProvider<double>((ref) => 1.0);
final brighteningFactorProvider = StateProvider<double>((ref) => 1.5);
final backgroundBlurProvider = StateProvider<double>((ref) => 0.0);
final backgroundDimProvider = StateProvider<double>((ref) => 0.0);

// UI state providers
final showBeforeAfterProvider = StateProvider<bool>((ref) => false);
final selectedBackgroundProvider = StateProvider<File?>((ref) => null);
final isPreviewModeProvider = StateProvider<bool>((ref) => false);

// Settings providers
final autoSaveProvider = StateProvider<bool>((ref) => true);
final highQualityExportProvider = StateProvider<bool>((ref) => false);
final watermarkEnabledProvider = StateProvider<bool>((ref) => false);

