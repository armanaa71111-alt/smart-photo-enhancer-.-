import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import '../models/photo_model.dart';
import '../providers/photo_provider.dart';

class BackgroundControls extends ConsumerWidget {
  final String? fileId;
  final VoidCallback? onBackgroundChanged;

  const BackgroundControls({
    super.key,
    this.fileId,
    this.onBackgroundChanged,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final photoState = ref.watch(photoProvider);
    final selectedBackground = ref.watch(selectedBackgroundProvider);
    final backgroundBlur = ref.watch(backgroundBlurProvider);
    final backgroundDim = ref.watch(backgroundDimProvider);

    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Background Tools',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 16),

          // Remove Background
          _buildBackgroundCard(
            context: context,
            title: 'Remove Background',
            description: 'Remove the current background',
            icon: Icons.layers_clear,
            color: Colors.red,
            isProcessing: photoState.isLoading,
            onTap: () => _removeBackground(context, ref),
          ),

          const SizedBox(height: 12),

          // Replace Background
          _buildBackgroundCard(
            context: context,
            title: 'Replace Background',
            description: 'Choose a new background image',
            icon: Icons.image,
            color: Colors.blue,
            isProcessing: photoState.isLoading,
            onTap: () => _selectCustomBackground(context, ref),
            child: selectedBackground != null
                ? Column(
                    children: [
                      const SizedBox(height: 12),
                      Container(
                        height: 80,
                        width: double.infinity,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(8),
                          image: DecorationImage(
                            image: FileImage(selectedBackground),
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                      const SizedBox(height: 12),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text('Blur Amount'),
                          Text('${(backgroundBlur * 100).round()}%'),
                        ],
                      ),
                      Slider(
                        value: backgroundBlur,
                        min: 0.0,
                        max: 1.0,
                        onChanged: (value) {
                          ref.read(backgroundBlurProvider.notifier).state = value;
                        },
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text('Dim Amount'),
                          Text('${(backgroundDim * 100).round()}%'),
                        ],
                      ),
                      Slider(
                        value: backgroundDim,
                        min: 0.0,
                        max: 1.0,
                        onChanged: (value) {
                          ref.read(backgroundDimProvider.notifier).state = value;
                        },
                      ),
                      ElevatedButton(
                        onPressed: photoState.isLoading
                            ? null
                            : () => _replaceBackground(context, ref),
                        child: const Text('Apply Background'),
                      ),
                    ],
                  )
                : null,
          ),

          const SizedBox(height: 16),

          // Preset Backgrounds
          const Text(
            'Preset Backgrounds',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 12),

          SizedBox(
            height: 100,
            child: ListView(
              scrollDirection: Axis.horizontal,
              children: [
                _buildPresetBackground(
                  context: context,
                  ref: ref,
                  title: 'White',
                  color: Colors.white,
                ),
                _buildPresetBackground(
                  context: context,
                  ref: ref,
                  title: 'Black',
                  color: Colors.black,
                ),
                _buildPresetBackground(
                  context: context,
                  ref: ref,
                  title: 'Blue',
                  gradient: const LinearGradient(
                    colors: [Colors.blue, Colors.lightBlue],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                _buildPresetBackground(
                  context: context,
                  ref: ref,
                  title: 'Purple',
                  gradient: const LinearGradient(
                    colors: [Colors.purple, Colors.pink],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                _buildPresetBackground(
                  context: context,
                  ref: ref,
                  title: 'Green',
                  gradient: const LinearGradient(
                    colors: [Colors.green, Colors.lightGreen],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
              ],
            ),
          ),

          const SizedBox(height: 16),

          // Error display
          if (photoState.error != null)
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: Colors.red[50],
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.red[200]!),
              ),
              child: Row(
                children: [
                  Icon(Icons.error_outline, color: Colors.red[700]),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      photoState.error!,
                      style: TextStyle(color: Colors.red[700]),
                    ),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close),
                    onPressed: () {
                      ref.read(photoProvider.notifier).clearError();
                    },
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildBackgroundCard({
    required BuildContext context,
    required String title,
    required String description,
    required IconData icon,
    required Color color,
    required bool isProcessing,
    required VoidCallback onTap,
    Widget? child,
  }) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
      ),
      child: InkWell(
        onTap: isProcessing ? null : onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(8),
                    decoration: BoxDecoration(
                      color: color.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Icon(icon, color: color, size: 24),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          title,
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          description,
                          style: TextStyle(
                            fontSize: 12,
                            color: Colors.grey[600],
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (isProcessing)
                    const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  else
                    Icon(
                      Icons.arrow_forward_ios,
                      size: 16,
                      color: Colors.grey[400],
                    ),
                ],
              ),
              if (child != null) child,
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildPresetBackground({
    required BuildContext context,
    required WidgetRef ref,
    required String title,
    Color? color,
    Gradient? gradient,
  }) {
    return Container(
      width: 80,
      margin: const EdgeInsets.only(right: 12),
      child: Column(
        children: [
          Expanded(
            child: GestureDetector(
              onTap: () => _selectPresetBackground(context, ref, title),
              child: Container(
                width: double.infinity,
                decoration: BoxDecoration(
                  color: color,
                  gradient: gradient,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.grey[300]!),
                ),
              ),
            ),
          ),
          const SizedBox(height: 4),
          Text(
            title,
            style: const TextStyle(fontSize: 12),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Future<void> _removeBackground(BuildContext context, WidgetRef ref) async {
    if (fileId == null) return;

    await ref.read(photoProvider.notifier).applyEnhancement(
      fileId!,
      EnhancementType.backgroundRemoval,
    );
    onBackgroundChanged?.call();
  }

  Future<void> _selectCustomBackground(BuildContext context, WidgetRef ref) async {
    final ImagePicker picker = ImagePicker();
    
    try {
      final XFile? image = await picker.pickImage(
        source: ImageSource.gallery,
        imageQuality: 90,
      );

      if (image != null) {
        ref.read(selectedBackgroundProvider.notifier).state = File(image.path);
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to select background: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  Future<void> _replaceBackground(BuildContext context, WidgetRef ref) async {
    if (fileId == null) return;

    final selectedBackground = ref.read(selectedBackgroundProvider);
    if (selectedBackground == null) return;

    final blurAmount = ref.read(backgroundBlurProvider);
    final dimAmount = ref.read(backgroundDimProvider);

    await ref.read(photoProvider.notifier).applyEnhancement(
      fileId!,
      EnhancementType.backgroundReplacement,
      parameters: {
        'backgroundFile': selectedBackground,
        'blurAmount': blurAmount,
        'dimAmount': dimAmount,
      },
    );
    onBackgroundChanged?.call();
  }

  Future<void> _selectPresetBackground(BuildContext context, WidgetRef ref, String preset) async {
    // Create a temporary preset background file
    // In a real app, you would have preset background images in assets
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('$preset background selected'),
        backgroundColor: Colors.blue,
      ),
    );
  }
}

