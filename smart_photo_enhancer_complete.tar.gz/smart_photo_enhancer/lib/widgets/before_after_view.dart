import 'dart:io';
import 'package:flutter/material.dart';
import '../models/photo_model.dart';

class BeforeAfterView extends StatefulWidget {
  final PhotoModel photo;

  const BeforeAfterView({
    super.key,
    required this.photo,
  });

  @override
  State<BeforeAfterView> createState() => _BeforeAfterViewState();
}

class _BeforeAfterViewState extends State<BeforeAfterView> {
  double _sliderValue = 0.5;

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        // Background (After image or original if no processed version)
        Positioned.fill(
          child: Image.file(
            File(widget.photo.processedPath ?? widget.photo.originalPath),
            fit: BoxFit.contain,
          ),
        ),

        // Foreground (Before image) with clipping
        if (widget.photo.processedPath != null)
          Positioned.fill(
            child: ClipRect(
              clipper: _BeforeImageClipper(_sliderValue),
              child: Image.file(
                File(widget.photo.originalPath),
                fit: BoxFit.contain,
              ),
            ),
          ),

        // Slider line
        if (widget.photo.processedPath != null)
          Positioned(
            left: MediaQuery.of(context).size.width * _sliderValue - 1,
            top: 0,
            bottom: 0,
            child: Container(
              width: 2,
              color: Colors.white,
            ),
          ),

        // Slider handle
        if (widget.photo.processedPath != null)
          Positioned(
            left: MediaQuery.of(context).size.width * _sliderValue - 20,
            top: MediaQuery.of(context).size.height * 0.4,
            child: GestureDetector(
              onPanUpdate: (details) {
                setState(() {
                  _sliderValue = (details.globalPosition.dx / MediaQuery.of(context).size.width)
                      .clamp(0.0, 1.0);
                });
              },
              child: Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: Colors.white,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.3),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: const Icon(
                  Icons.compare_arrows,
                  color: Colors.blue,
                ),
              ),
            ),
          ),

        // Labels
        Positioned(
          top: 20,
          left: 20,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.7),
              borderRadius: BorderRadius.circular(16),
            ),
            child: const Text(
              'BEFORE',
              style: TextStyle(
                color: Colors.white,
                fontSize: 12,
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ),

        if (widget.photo.processedPath != null)
          Positioned(
            top: 20,
            right: 20,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.7),
                borderRadius: BorderRadius.circular(16),
              ),
              child: const Text(
                'AFTER',
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 12,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ),

        // Instructions
        if (widget.photo.processedPath != null)
          Positioned(
            bottom: 20,
            left: 0,
            right: 0,
            child: Center(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                decoration: BoxDecoration(
                  color: Colors.black.withOpacity(0.7),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: const Text(
                  'Drag the slider to compare',
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 12,
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }
}

class _BeforeImageClipper extends CustomClipper<Rect> {
  final double sliderValue;

  _BeforeImageClipper(this.sliderValue);

  @override
  Rect getClip(Size size) {
    return Rect.fromLTRB(0, 0, size.width * sliderValue, size.height);
  }

  @override
  bool shouldReclip(covariant CustomClipper<Rect> oldClipper) {
    return true;
  }
}

