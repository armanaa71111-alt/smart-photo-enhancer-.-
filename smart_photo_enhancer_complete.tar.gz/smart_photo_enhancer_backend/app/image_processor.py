import cv2
import numpy as np
from PIL import Image, ImageEnhance, ImageFilter
import asyncio
from typing import Tuple, Optional

class ImageProcessor:
    """Base class for image processing operations"""
    
    def __init__(self):
        self.supported_formats = ['.jpg', '.jpeg', '.png', '.bmp', '.tiff']
    
    async def load_image(self, image_path: str) -> np.ndarray:
        """Load image from file path"""
        try:
            image = cv2.imread(image_path)
            if image is None:
                raise ValueError(f"Could not load image from {image_path}")
            return cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        except Exception as e:
            raise Exception(f"Error loading image: {str(e)}")
    
    async def load_image_pil(self, image_path: str) -> Image.Image:
        """Load image using PIL"""
        try:
            return Image.open(image_path).convert('RGB')
        except Exception as e:
            raise Exception(f"Error loading image with PIL: {str(e)}")
    
    async def save_image(self, image: np.ndarray, output_path: str):
        """Save numpy array as image"""
        try:
            if len(image.shape) == 3:
                image_bgr = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
            else:
                image_bgr = image
            cv2.imwrite(output_path, image_bgr)
        except Exception as e:
            raise Exception(f"Error saving image: {str(e)}")
    
    async def save_image_pil(self, image: Image.Image, output_path: str):
        """Save PIL image"""
        try:
            image.save(output_path, 'PNG', quality=95)
        except Exception as e:
            raise Exception(f"Error saving PIL image: {str(e)}")
    
    async def resize_image(self, image: np.ndarray, target_size: Tuple[int, int]) -> np.ndarray:
        """Resize image to target size"""
        return cv2.resize(image, target_size, interpolation=cv2.INTER_LANCZOS4)
    
    async def resize_image_pil(self, image: Image.Image, target_size: Tuple[int, int]) -> Image.Image:
        """Resize PIL image to target size"""
        return image.resize(target_size, Image.Resampling.LANCZOS)
    
    def normalize_image(self, image: np.ndarray) -> np.ndarray:
        """Normalize image values to 0-255 range"""
        image = np.clip(image, 0, 255)
        return image.astype(np.uint8)
    
    async def apply_gaussian_blur(self, image: np.ndarray, kernel_size: int = 5, sigma: float = 1.0) -> np.ndarray:
        """Apply Gaussian blur to image"""
        return cv2.GaussianBlur(image, (kernel_size, kernel_size), sigma)
    
    async def adjust_brightness_contrast(self, image: np.ndarray, brightness: float = 0, contrast: float = 1.0) -> np.ndarray:
        """Adjust brightness and contrast of image"""
        adjusted = cv2.convertScaleAbs(image, alpha=contrast, beta=brightness)
        return adjusted
    
    async def convert_to_grayscale(self, image: np.ndarray) -> np.ndarray:
        """Convert image to grayscale"""
        return cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
    
    async def apply_histogram_equalization(self, image: np.ndarray) -> np.ndarray:
        """Apply histogram equalization for better contrast"""
        if len(image.shape) == 3:
            # Convert to YUV and equalize Y channel
            yuv = cv2.cvtColor(image, cv2.COLOR_RGB2YUV)
            yuv[:,:,0] = cv2.equalizeHist(yuv[:,:,0])
            return cv2.cvtColor(yuv, cv2.COLOR_YUV2RGB)
        else:
            return cv2.equalizeHist(image)
    
    async def apply_clahe(self, image: np.ndarray, clip_limit: float = 2.0, tile_grid_size: Tuple[int, int] = (8, 8)) -> np.ndarray:
        """Apply Contrast Limited Adaptive Histogram Equalization"""
        clahe = cv2.createCLAHE(clipLimit=clip_limit, tileGridSize=tile_grid_size)
        
        if len(image.shape) == 3:
            # Convert to LAB and apply CLAHE to L channel
            lab = cv2.cvtColor(image, cv2.COLOR_RGB2LAB)
            lab[:,:,0] = clahe.apply(lab[:,:,0])
            return cv2.cvtColor(lab, cv2.COLOR_LAB2RGB)
        else:
            return clahe.apply(image)
    
    async def detect_faces(self, image: np.ndarray) -> list:
        """Detect faces in image using OpenCV"""
        try:
            # Load face cascade classifier
            face_cascade = cv2.CascadeClassifier(cv2.data.haarcascades + 'haarcascade_frontalface_default.xml')
            gray = await self.convert_to_grayscale(image)
            faces = face_cascade.detectMultiScale(gray, 1.1, 4)
            return faces.tolist() if len(faces) > 0 else []
        except Exception as e:
            print(f"Face detection error: {str(e)}")
            return []
    
    async def get_image_stats(self, image: np.ndarray) -> dict:
        """Get basic statistics about the image"""
        return {
            "shape": image.shape,
            "dtype": str(image.dtype),
            "min_value": float(np.min(image)),
            "max_value": float(np.max(image)),
            "mean_value": float(np.mean(image)),
            "std_value": float(np.std(image))
        }

