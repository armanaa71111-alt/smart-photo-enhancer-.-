import cv2
import numpy as np
from PIL import Image, ImageEnhance, ImageFilter
import asyncio
from skimage import restoration, filters, exposure
from skimage.filters import unsharp_mask
import torch
import torch.nn.functional as F
from .image_processor import ImageProcessor

class EnhancementProcessor(ImageProcessor):
    """Image enhancement processor with AI-powered features"""
    
    def __init__(self):
        super().__init__()
        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    
    async def enhance_quality(self, input_path: str, output_path: str, scale: int = 2):
        """Enhance image quality using super-resolution techniques"""
        try:
            # Load image
            image = await self.load_image_pil(input_path)
            
            # Simple upscaling with high-quality resampling
            width, height = image.size
            new_size = (width * scale, height * scale)
            
            # Use LANCZOS for high-quality upscaling
            enhanced = image.resize(new_size, Image.Resampling.LANCZOS)
            
            # Apply sharpening filter
            enhanced = enhanced.filter(ImageFilter.UnsharpMask(radius=1, percent=150, threshold=3))
            
            # Enhance contrast slightly
            enhancer = ImageEnhance.Contrast(enhanced)
            enhanced = enhancer.enhance(1.1)
            
            # Save enhanced image
            await self.save_image_pil(enhanced, output_path)
            
        except Exception as e:
            raise Exception(f"Quality enhancement failed: {str(e)}")
    
    async def auto_color_correction(self, input_path: str, output_path: str):
        """Apply automatic color correction"""
        try:
            # Load image
            image = await self.load_image(input_path)
            
            # Convert to LAB color space for better color manipulation
            lab = cv2.cvtColor(image, cv2.COLOR_RGB2LAB)
            
            # Apply CLAHE to L channel for better contrast
            clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8, 8))
            lab[:,:,0] = clahe.apply(lab[:,:,0])
            
            # Convert back to RGB
            corrected = cv2.cvtColor(lab, cv2.COLOR_LAB2RGB)
            
            # Auto white balance
            corrected = await self.auto_white_balance(corrected)
            
            # Enhance saturation slightly
            hsv = cv2.cvtColor(corrected, cv2.COLOR_RGB2HSV)
            hsv[:,:,1] = cv2.multiply(hsv[:,:,1], 1.2)  # Increase saturation
            corrected = cv2.cvtColor(hsv, cv2.COLOR_HSV2RGB)
            
            # Save corrected image
            await self.save_image(corrected, output_path)
            
        except Exception as e:
            raise Exception(f"Color correction failed: {str(e)}")
    
    async def auto_white_balance(self, image: np.ndarray) -> np.ndarray:
        """Apply automatic white balance"""
        # Gray world assumption
        avg_r = np.mean(image[:,:,0])
        avg_g = np.mean(image[:,:,1])
        avg_b = np.mean(image[:,:,2])
        
        avg_gray = (avg_r + avg_g + avg_b) / 3
        
        # Calculate scaling factors
        scale_r = avg_gray / avg_r if avg_r > 0 else 1
        scale_g = avg_gray / avg_g if avg_g > 0 else 1
        scale_b = avg_gray / avg_b if avg_b > 0 else 1
        
        # Apply scaling
        balanced = image.copy().astype(np.float32)
        balanced[:,:,0] *= scale_r
        balanced[:,:,1] *= scale_g
        balanced[:,:,2] *= scale_b
        
        return self.normalize_image(balanced)
    
    async def sharpen_image(self, input_path: str, output_path: str, strength: float = 1.0):
        """Sharpen image and enhance details"""
        try:
            # Load image
            image = await self.load_image(input_path)
            
            # Convert to float for processing
            image_float = image.astype(np.float32) / 255.0
            
            # Apply unsharp mask
            sharpened = unsharp_mask(image_float, radius=1.0, amount=strength)
            
            # Convert back to uint8
            sharpened = self.normalize_image(sharpened * 255)
            
            # Additional edge enhancement
            kernel = np.array([[-1,-1,-1],
                              [-1, 9,-1],
                              [-1,-1,-1]])
            
            # Apply kernel to each channel
            for i in range(3):
                channel = cv2.filter2D(sharpened[:,:,i], -1, kernel)
                sharpened[:,:,i] = cv2.addWeighted(sharpened[:,:,i], 0.7, channel, 0.3, 0)
            
            # Save sharpened image
            await self.save_image(sharpened, output_path)
            
        except Exception as e:
            raise Exception(f"Sharpening failed: {str(e)}")
    
    async def denoise_image(self, input_path: str, output_path: str):
        """Remove noise from image"""
        try:
            # Load image
            image = await self.load_image(input_path)
            
            # Apply Non-local Means Denoising
            if len(image.shape) == 3:
                denoised = cv2.fastNlMeansDenoisingColored(image, None, 10, 10, 7, 21)
            else:
                denoised = cv2.fastNlMeansDenoising(image, None, 10, 7, 21)
            
            # Additional bilateral filtering for edge preservation
            denoised = cv2.bilateralFilter(denoised, 9, 75, 75)
            
            # Save denoised image
            await self.save_image(denoised, output_path)
            
        except Exception as e:
            raise Exception(f"Denoising failed: {str(e)}")
    
    async def brighten_image(self, input_path: str, output_path: str, factor: float = 1.5):
        """Brighten low-light photos"""
        try:
            # Load image
            image = await self.load_image(input_path)
            
            # Convert to LAB for better brightness control
            lab = cv2.cvtColor(image, cv2.COLOR_RGB2LAB)
            
            # Enhance L channel (lightness)
            l_channel = lab[:,:,0].astype(np.float32)
            l_channel = l_channel * factor
            l_channel = np.clip(l_channel, 0, 255)
            lab[:,:,0] = l_channel.astype(np.uint8)
            
            # Convert back to RGB
            brightened = cv2.cvtColor(lab, cv2.COLOR_LAB2RGB)
            
            # Apply gamma correction for better low-light enhancement
            gamma = 0.7  # Lower gamma for brightening
            brightened = np.power(brightened / 255.0, gamma) * 255.0
            brightened = self.normalize_image(brightened)
            
            # Enhance shadows specifically
            brightened = await self.enhance_shadows(brightened)
            
            # Save brightened image
            await self.save_image(brightened, output_path)
            
        except Exception as e:
            raise Exception(f"Brightening failed: {str(e)}")
    
    async def enhance_shadows(self, image: np.ndarray) -> np.ndarray:
        """Enhance shadow areas specifically"""
        # Create shadow mask (dark areas)
        gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
        shadow_mask = gray < 100  # Threshold for shadow areas
        
        # Enhance only shadow areas
        enhanced = image.copy().astype(np.float32)
        for i in range(3):
            channel = enhanced[:,:,i]
            channel[shadow_mask] *= 1.3  # Brighten shadows
            enhanced[:,:,i] = channel
        
        return self.normalize_image(enhanced)
    
    async def face_retouching(self, input_path: str, output_path: str):
        """Apply face retouching including skin smoothing, teeth whitening, and eye sharpening"""
        try:
            # Load image
            image = await self.load_image(input_path)
            
            # Detect faces
            faces = await self.detect_faces(image)
            
            if not faces:
                # No faces detected, just apply general skin smoothing
                retouched = await self.apply_skin_smoothing(image)
            else:
                retouched = image.copy()
                
                # Process each detected face
                for (x, y, w, h) in faces:
                    # Extract face region
                    face_region = image[y:y+h, x:x+w]
                    
                    # Apply face-specific enhancements
                    enhanced_face = await self.enhance_face_region(face_region)
                    
                    # Replace face region in original image
                    retouched[y:y+h, x:x+w] = enhanced_face
            
            # Save retouched image
            await self.save_image(retouched, output_path)
            
        except Exception as e:
            raise Exception(f"Face retouching failed: {str(e)}")
    
    async def apply_skin_smoothing(self, image: np.ndarray) -> np.ndarray:
        """Apply skin smoothing to the entire image"""
        # Create a smoothed version using bilateral filter
        smoothed = cv2.bilateralFilter(image, 15, 80, 80)
        
        # Create skin mask (simplified skin detection)
        skin_mask = await self.create_skin_mask(image)
        
        # Blend original and smoothed based on skin mask
        result = image.copy().astype(np.float32)
        for i in range(3):
            result[:,:,i] = np.where(skin_mask, 
                                   0.7 * image[:,:,i] + 0.3 * smoothed[:,:,i],
                                   image[:,:,i])
        
        return self.normalize_image(result)
    
    async def create_skin_mask(self, image: np.ndarray) -> np.ndarray:
        """Create a simple skin detection mask"""
        # Convert to YCrCb color space for better skin detection
        ycrcb = cv2.cvtColor(image, cv2.COLOR_RGB2YCrCb)
        
        # Define skin color range in YCrCb
        lower_skin = np.array([0, 133, 77], dtype=np.uint8)
        upper_skin = np.array([255, 173, 127], dtype=np.uint8)
        
        # Create mask
        skin_mask = cv2.inRange(ycrcb, lower_skin, upper_skin)
        
        # Apply morphological operations to clean up the mask
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (11, 11))
        skin_mask = cv2.morphologyEx(skin_mask, cv2.MORPH_OPEN, kernel)
        skin_mask = cv2.morphologyEx(skin_mask, cv2.MORPH_CLOSE, kernel)
        
        # Apply Gaussian blur to soften edges
        skin_mask = cv2.GaussianBlur(skin_mask, (3, 3), 0)
        
        return skin_mask.astype(bool)
    
    async def enhance_face_region(self, face_region: np.ndarray) -> np.ndarray:
        """Enhance a specific face region"""
        enhanced = face_region.copy()
        
        # Skin smoothing
        enhanced = cv2.bilateralFilter(enhanced, 15, 80, 80)
        
        # Eye enhancement (sharpen upper portion of face)
        h, w = face_region.shape[:2]
        eye_region = enhanced[:h//2, :]  # Upper half for eyes
        
        # Apply sharpening to eye region
        kernel = np.array([[-1,-1,-1],
                          [-1, 9,-1],
                          [-1,-1,-1]])
        
        for i in range(3):
            eye_region[:,:,i] = cv2.filter2D(eye_region[:,:,i], -1, kernel)
        
        enhanced[:h//2, :] = eye_region
        
        # Teeth whitening (lower portion of face)
        teeth_region = enhanced[h//2:, w//4:3*w//4]  # Lower center for mouth area
        
        # Convert to HSV and increase brightness in potential teeth areas
        hsv = cv2.cvtColor(teeth_region, cv2.COLOR_RGB2HSV)
        
        # Create mask for bright areas (potential teeth)
        bright_mask = hsv[:,:,2] > 150
        
        # Whiten teeth areas
        hsv[:,:,1][bright_mask] = hsv[:,:,1][bright_mask] * 0.5  # Reduce saturation
        hsv[:,:,2][bright_mask] = np.minimum(hsv[:,:,2][bright_mask] * 1.1, 255)  # Increase brightness
        
        teeth_whitened = cv2.cvtColor(hsv, cv2.COLOR_HSV2RGB)
        enhanced[h//2:, w//4:3*w//4] = teeth_whitened
        
        return enhanced

