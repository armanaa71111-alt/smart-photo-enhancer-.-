import cv2
import numpy as np
from PIL import Image
import asyncio
from rembg import remove, new_session
from .image_processor import ImageProcessor

class BackgroundProcessor(ImageProcessor):
    """Background processing with U²-Net and other techniques"""
    
    def __init__(self):
        super().__init__()
        # Initialize rembg session for background removal
        try:
            self.bg_session = new_session('u2net')
        except Exception as e:
            print(f"Warning: Could not initialize U2Net session: {e}")
            self.bg_session = None
    
    async def remove_background(self, input_path: str, output_path: str):
        """Remove background using U²-Net"""
        try:
            # Load image
            with open(input_path, 'rb') as input_file:
                input_data = input_file.read()
            
            # Remove background using rembg
            if self.bg_session:
                output_data = remove(input_data, session=self.bg_session)
            else:
                # Fallback to default rembg
                output_data = remove(input_data)
            
            # Save result
            with open(output_path, 'wb') as output_file:
                output_file.write(output_data)
                
        except Exception as e:
            # Fallback to traditional background removal
            await self.remove_background_traditional(input_path, output_path)
    
    async def remove_background_traditional(self, input_path: str, output_path: str):
        """Traditional background removal using GrabCut algorithm"""
        try:
            # Load image
            image = await self.load_image(input_path)
            
            # Create mask for GrabCut
            mask = np.zeros(image.shape[:2], np.uint8)
            
            # Define rectangle around the main subject (center 80% of image)
            height, width = image.shape[:2]
            rect = (int(width*0.1), int(height*0.1), int(width*0.8), int(height*0.8))
            
            # Initialize background and foreground models
            bgd_model = np.zeros((1, 65), np.float64)
            fgd_model = np.zeros((1, 65), np.float64)
            
            # Apply GrabCut
            cv2.grabCut(image, mask, rect, bgd_model, fgd_model, 5, cv2.GC_INIT_WITH_RECT)
            
            # Create final mask
            mask2 = np.where((mask == 2) | (mask == 0), 0, 1).astype('uint8')
            
            # Apply mask to image
            result = image * mask2[:, :, np.newaxis]
            
            # Convert to RGBA for transparency
            result_rgba = np.zeros((height, width, 4), dtype=np.uint8)
            result_rgba[:, :, :3] = result
            result_rgba[:, :, 3] = mask2 * 255  # Alpha channel
            
            # Save as PNG with transparency
            result_pil = Image.fromarray(result_rgba, 'RGBA')
            await self.save_image_pil(result_pil, output_path)
            
        except Exception as e:
            raise Exception(f"Traditional background removal failed: {str(e)}")
    
    async def replace_background(self, input_path: str, background_path: str, output_path: str, 
                               blur_amount: float = 0.0, dim_amount: float = 0.0):
        """Replace background with custom image"""
        try:
            # First remove the background
            temp_no_bg = output_path.replace('.png', '_temp_no_bg.png')
            await self.remove_background(input_path, temp_no_bg)
            
            # Load images
            subject = Image.open(temp_no_bg).convert('RGBA')
            background = Image.open(background_path).convert('RGB')
            
            # Resize background to match subject
            background = background.resize(subject.size, Image.Resampling.LANCZOS)
            
            # Apply blur to background if requested
            if blur_amount > 0:
                background = await self.apply_blur_pil(background, blur_amount)
            
            # Apply dimming to background if requested
            if dim_amount > 0:
                background = await self.apply_dimming_pil(background, dim_amount)
            
            # Create final composite
            final_image = Image.new('RGB', subject.size)
            final_image.paste(background, (0, 0))
            final_image.paste(subject, (0, 0), subject)
            
            # Save result
            await self.save_image_pil(final_image, output_path)
            
            # Clean up temporary file
            import os
            if os.path.exists(temp_no_bg):
                os.remove(temp_no_bg)
                
        except Exception as e:
            raise Exception(f"Background replacement failed: {str(e)}")
    
    async def apply_blur_pil(self, image: Image.Image, blur_amount: float) -> Image.Image:
        """Apply blur to PIL image"""
        from PIL import ImageFilter
        return image.filter(ImageFilter.GaussianBlur(radius=blur_amount))
    
    async def apply_dimming_pil(self, image: Image.Image, dim_amount: float) -> Image.Image:
        """Apply dimming to PIL image"""
        from PIL import ImageEnhance
        enhancer = ImageEnhance.Brightness(image)
        return enhancer.enhance(1.0 - dim_amount)
    
    async def create_preset_backgrounds(self, output_dir: str):
        """Create preset background images"""
        import os
        os.makedirs(output_dir, exist_ok=True)
        
        # Create gradient backgrounds
        await self.create_gradient_background(output_dir + "/gradient_blue.png", (0, 100, 255), (0, 200, 255))
        await self.create_gradient_background(output_dir + "/gradient_purple.png", (128, 0, 255), (255, 0, 128))
        await self.create_gradient_background(output_dir + "/gradient_green.png", (0, 255, 100), (100, 255, 0))
        
        # Create solid color backgrounds
        await self.create_solid_background(output_dir + "/solid_white.png", (255, 255, 255))
        await self.create_solid_background(output_dir + "/solid_black.png", (0, 0, 0))
        await self.create_solid_background(output_dir + "/solid_gray.png", (128, 128, 128))
    
    async def create_gradient_background(self, output_path: str, color1: tuple, color2: tuple, size: tuple = (1080, 1920)):
        """Create gradient background"""
        width, height = size
        
        # Create gradient
        gradient = np.zeros((height, width, 3), dtype=np.uint8)
        
        for y in range(height):
            ratio = y / height
            r = int(color1[0] * (1 - ratio) + color2[0] * ratio)
            g = int(color1[1] * (1 - ratio) + color2[1] * ratio)
            b = int(color1[2] * (1 - ratio) + color2[2] * ratio)
            gradient[y, :] = [r, g, b]
        
        # Save gradient
        gradient_pil = Image.fromarray(gradient, 'RGB')
        await self.save_image_pil(gradient_pil, output_path)
    
    async def create_solid_background(self, output_path: str, color: tuple, size: tuple = (1080, 1920)):
        """Create solid color background"""
        width, height = size
        
        # Create solid color image
        solid = Image.new('RGB', (width, height), color)
        await self.save_image_pil(solid, output_path)
    
    async def edge_refinement(self, mask: np.ndarray) -> np.ndarray:
        """Refine edges of the mask for better cutout quality"""
        # Apply morphological operations
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (3, 3))
        
        # Close small holes
        mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
        
        # Smooth edges
        mask = cv2.GaussianBlur(mask, (3, 3), 0)
        
        return mask
    
    async def feather_edges(self, mask: np.ndarray, feather_amount: int = 5) -> np.ndarray:
        """Apply feathering to mask edges for smoother blending"""
        # Create distance transform
        dist_transform = cv2.distanceTransform(mask, cv2.DIST_L2, 5)
        
        # Normalize and apply feathering
        feathered = np.clip(dist_transform / feather_amount, 0, 1)
        
        return (feathered * 255).astype(np.uint8)
    
    async def color_match_background(self, subject: np.ndarray, background: np.ndarray, mask: np.ndarray) -> np.ndarray:
        """Match colors between subject and background for better integration"""
        # Extract edge pixels of the subject
        edge_mask = cv2.Canny(mask, 50, 150)
        edge_mask = cv2.dilate(edge_mask, np.ones((5, 5), np.uint8), iterations=1)
        
        # Get subject edge colors
        subject_edges = subject[edge_mask > 0]
        
        if len(subject_edges) > 0:
            # Calculate average edge color
            avg_subject_color = np.mean(subject_edges, axis=0)
            
            # Get corresponding background colors
            background_edges = background[edge_mask > 0]
            avg_background_color = np.mean(background_edges, axis=0)
            
            # Calculate color adjustment
            color_diff = avg_background_color - avg_subject_color
            
            # Apply subtle color adjustment to subject edges
            adjusted_subject = subject.copy().astype(np.float32)
            edge_region = edge_mask > 0
            
            for i in range(3):
                adjusted_subject[edge_region, i] += color_diff[i] * 0.3  # Subtle adjustment
            
            adjusted_subject = np.clip(adjusted_subject, 0, 255).astype(np.uint8)
            return adjusted_subject
        
        return subject
    
    async def create_shadow(self, subject_mask: np.ndarray, shadow_offset: tuple = (10, 10), 
                          shadow_blur: int = 15, shadow_opacity: float = 0.3) -> np.ndarray:
        """Create a realistic shadow for the subject"""
        height, width = subject_mask.shape
        
        # Create shadow mask
        shadow_mask = np.zeros((height, width), dtype=np.uint8)
        
        # Offset the subject mask to create shadow position
        offset_x, offset_y = shadow_offset
        
        # Create transformation matrix for shadow offset
        M = np.float32([[1, 0, offset_x], [0, 1, offset_y]])
        shadow_mask = cv2.warpAffine(subject_mask, M, (width, height))
        
        # Apply blur to create soft shadow
        shadow_mask = cv2.GaussianBlur(shadow_mask, (shadow_blur, shadow_blur), 0)
        
        # Apply opacity
        shadow_mask = (shadow_mask * shadow_opacity).astype(np.uint8)
        
        return shadow_mask

