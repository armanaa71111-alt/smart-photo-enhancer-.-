from fastapi import FastAPI, File, UploadFile, HTTPException, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
import uvicorn
import os
import uuid
from typing import Optional
import asyncio
from pathlib import Path

from app.image_processor import ImageProcessor
from app.background_processor import BackgroundProcessor
from app.enhancement_processor import EnhancementProcessor

# Create FastAPI app
app = FastAPI(
    title="Smart Photo Enhancer API",
    description="AI-powered photo enhancement and editing API",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Create upload and output directories
UPLOAD_DIR = Path("uploads")
OUTPUT_DIR = Path("outputs")
UPLOAD_DIR.mkdir(exist_ok=True)
OUTPUT_DIR.mkdir(exist_ok=True)

# Initialize processors
image_processor = ImageProcessor()
background_processor = BackgroundProcessor()
enhancement_processor = EnhancementProcessor()

@app.get("/")
async def root():
    return {"message": "Smart Photo Enhancer API", "version": "1.0.0"}

@app.get("/health")
async def health_check():
    return {"status": "healthy", "message": "API is running"}

@app.post("/upload")
async def upload_image(file: UploadFile = File(...)):
    """Upload an image for processing"""
    if not file.content_type.startswith("image/"):
        raise HTTPException(status_code=400, detail="File must be an image")
    
    # Generate unique filename
    file_id = str(uuid.uuid4())
    file_extension = file.filename.split(".")[-1]
    filename = f"{file_id}.{file_extension}"
    file_path = UPLOAD_DIR / filename
    
    # Save uploaded file
    with open(file_path, "wb") as buffer:
        content = await file.read()
        buffer.write(content)
    
    return {
        "file_id": file_id,
        "filename": filename,
        "message": "Image uploaded successfully"
    }

@app.post("/enhance/quality")
async def enhance_quality(
    file_id: str = Form(...),
    scale: int = Form(default=2)
):
    """Enhance image quality using ESRGAN"""
    input_path = UPLOAD_DIR / f"{file_id}.jpg"
    if not input_path.exists():
        input_path = UPLOAD_DIR / f"{file_id}.png"
        if not input_path.exists():
            raise HTTPException(status_code=404, detail="Image not found")
    
    output_filename = f"{file_id}_enhanced.png"
    output_path = OUTPUT_DIR / output_filename
    
    try:
        await enhancement_processor.enhance_quality(str(input_path), str(output_path), scale)
        return {
            "file_id": file_id,
            "output_filename": output_filename,
            "message": "Quality enhancement completed"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Enhancement failed: {str(e)}")

@app.post("/enhance/color")
async def auto_color_correction(file_id: str = Form(...)):
    """Apply automatic color correction"""
    input_path = UPLOAD_DIR / f"{file_id}.jpg"
    if not input_path.exists():
        input_path = UPLOAD_DIR / f"{file_id}.png"
        if not input_path.exists():
            raise HTTPException(status_code=404, detail="Image not found")
    
    output_filename = f"{file_id}_color_corrected.png"
    output_path = OUTPUT_DIR / output_filename
    
    try:
        await enhancement_processor.auto_color_correction(str(input_path), str(output_path))
        return {
            "file_id": file_id,
            "output_filename": output_filename,
            "message": "Color correction completed"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Color correction failed: {str(e)}")

@app.post("/enhance/sharpen")
async def sharpen_image(
    file_id: str = Form(...),
    strength: float = Form(default=1.0)
):
    """Sharpen image and enhance details"""
    input_path = UPLOAD_DIR / f"{file_id}.jpg"
    if not input_path.exists():
        input_path = UPLOAD_DIR / f"{file_id}.png"
        if not input_path.exists():
            raise HTTPException(status_code=404, detail="Image not found")
    
    output_filename = f"{file_id}_sharpened.png"
    output_path = OUTPUT_DIR / output_filename
    
    try:
        await enhancement_processor.sharpen_image(str(input_path), str(output_path), strength)
        return {
            "file_id": file_id,
            "output_filename": output_filename,
            "message": "Image sharpening completed"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Sharpening failed: {str(e)}")

@app.post("/enhance/denoise")
async def denoise_image(file_id: str = Form(...)):
    """Remove noise from image"""
    input_path = UPLOAD_DIR / f"{file_id}.jpg"
    if not input_path.exists():
        input_path = UPLOAD_DIR / f"{file_id}.png"
        if not input_path.exists():
            raise HTTPException(status_code=404, detail="Image not found")
    
    output_filename = f"{file_id}_denoised.png"
    output_path = OUTPUT_DIR / output_filename
    
    try:
        await enhancement_processor.denoise_image(str(input_path), str(output_path))
        return {
            "file_id": file_id,
            "output_filename": output_filename,
            "message": "Noise removal completed"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Denoising failed: {str(e)}")

@app.post("/enhance/brighten")
async def brighten_image(
    file_id: str = Form(...),
    factor: float = Form(default=1.5)
):
    """Brighten low-light photos"""
    input_path = UPLOAD_DIR / f"{file_id}.jpg"
    if not input_path.exists():
        input_path = UPLOAD_DIR / f"{file_id}.png"
        if not input_path.exists():
            raise HTTPException(status_code=404, detail="Image not found")
    
    output_filename = f"{file_id}_brightened.png"
    output_path = OUTPUT_DIR / output_filename
    
    try:
        await enhancement_processor.brighten_image(str(input_path), str(output_path), factor)
        return {
            "file_id": file_id,
            "output_filename": output_filename,
            "message": "Image brightening completed"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Brightening failed: {str(e)}")

@app.post("/enhance/face")
async def face_retouching(file_id: str = Form(...)):
    """Apply face retouching including skin smoothing, teeth whitening, and eye sharpening"""
    input_path = UPLOAD_DIR / f"{file_id}.jpg"
    if not input_path.exists():
        input_path = UPLOAD_DIR / f"{file_id}.png"
        if not input_path.exists():
            raise HTTPException(status_code=404, detail="Image not found")
    
    output_filename = f"{file_id}_face_retouched.png"
    output_path = OUTPUT_DIR / output_filename
    
    try:
        await enhancement_processor.face_retouching(str(input_path), str(output_path))
        return {
            "file_id": file_id,
            "output_filename": output_filename,
            "message": "Face retouching completed"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Face retouching failed: {str(e)}")

@app.post("/background/remove")
async def remove_background(file_id: str = Form(...)):
    """Remove background using U²-Net"""
    input_path = UPLOAD_DIR / f"{file_id}.jpg"
    if not input_path.exists():
        input_path = UPLOAD_DIR / f"{file_id}.png"
        if not input_path.exists():
            raise HTTPException(status_code=404, detail="Image not found")
    
    output_filename = f"{file_id}_no_bg.png"
    output_path = OUTPUT_DIR / output_filename
    
    try:
        await background_processor.remove_background(str(input_path), str(output_path))
        return {
            "file_id": file_id,
            "output_filename": output_filename,
            "message": "Background removal completed"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Background removal failed: {str(e)}")

@app.post("/background/replace")
async def replace_background(
    file_id: str = Form(...),
    background_file: UploadFile = File(...),
    blur_amount: float = Form(default=0.0),
    dim_amount: float = Form(default=0.0)
):
    """Replace background with custom image"""
    # Save background image
    bg_id = str(uuid.uuid4())
    bg_extension = background_file.filename.split(".")[-1]
    bg_filename = f"{bg_id}.{bg_extension}"
    bg_path = UPLOAD_DIR / bg_filename
    
    with open(bg_path, "wb") as buffer:
        bg_content = await background_file.read()
        buffer.write(bg_content)
    
    # Find original image
    input_path = UPLOAD_DIR / f"{file_id}.jpg"
    if not input_path.exists():
        input_path = UPLOAD_DIR / f"{file_id}.png"
        if not input_path.exists():
            raise HTTPException(status_code=404, detail="Image not found")
    
    output_filename = f"{file_id}_new_bg.png"
    output_path = OUTPUT_DIR / output_filename
    
    try:
        await background_processor.replace_background(
            str(input_path), 
            str(bg_path), 
            str(output_path),
            blur_amount,
            dim_amount
        )
        return {
            "file_id": file_id,
            "output_filename": output_filename,
            "message": "Background replacement completed"
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Background replacement failed: {str(e)}")

@app.get("/download/{filename}")
async def download_file(filename: str):
    """Download processed image"""
    file_path = OUTPUT_DIR / filename
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="File not found")
    
    return FileResponse(
        path=str(file_path),
        filename=filename,
        media_type="image/png"
    )

@app.delete("/cleanup/{file_id}")
async def cleanup_files(file_id: str):
    """Clean up uploaded and processed files"""
    files_deleted = 0
    
    # Clean up uploaded files
    for ext in ["jpg", "png", "jpeg"]:
        upload_path = UPLOAD_DIR / f"{file_id}.{ext}"
        if upload_path.exists():
            upload_path.unlink()
            files_deleted += 1
    
    # Clean up output files
    for output_file in OUTPUT_DIR.glob(f"{file_id}_*"):
        output_file.unlink()
        files_deleted += 1
    
    return {
        "file_id": file_id,
        "files_deleted": files_deleted,
        "message": "Cleanup completed"
    }

if __name__ == "__main__":
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=True
    )

